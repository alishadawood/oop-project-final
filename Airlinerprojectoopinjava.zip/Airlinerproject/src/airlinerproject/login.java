
package airlinerproject;

import java.awt.Color;
import javax.swing.*;
import javax.swing.JPasswordField;
import java.awt.*;


import javax.swing.JOptionPane;

public class login extends javax.swing.JFrame {
   
    
    
    public login() {
        initComponents();
       this.getContentPane().setBackground(Color.blue);
       himden();
       
       
    }

private void himden()
{
  //Name.setVisible(false);
  //Password.setVisible(false);
}
private boolean valid() {
   
    String name = Name.getText(); 
    String pass = new String(Password.getPassword());  

   
    if (name.isEmpty() || pass.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter both username and password!", "Error", JOptionPane.ERROR_MESSAGE);
        return false;  
    }

 
    String validUsername = "admin";
    String validPassword = "12345";

  
    if (name.equals(validUsername) && pass.equals(validPassword)) {
        JOptionPane.showMessageDialog(this, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
        return true;  
    } else {
        JOptionPane.showMessageDialog(this, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
        return false;  // Return false if the credentials are invalid
    }
}

            
            
            
            
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adminlogin = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();
        showpassword = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        Name = new javax.swing.JTextPane();
        Password = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        Password1 = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 102));
        setSize(new java.awt.Dimension(500, 350));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("UserName");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Password");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        adminlogin.setBackground(new java.awt.Color(0, 0, 153));
        adminlogin.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        adminlogin.setForeground(new java.awt.Color(255, 255, 255));
        adminlogin.setText(" Login");
        adminlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminloginActionPerformed(evt);
            }
        });
        jPanel1.add(adminlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 100, -1));

        Cancel.setBackground(new java.awt.Color(153, 0, 0));
        Cancel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        Cancel.setText("Logout");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        jPanel1.add(Cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 80, -1));

        showpassword.setBackground(new java.awt.Color(0, 102, 153));
        showpassword.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        showpassword.setForeground(new java.awt.Color(255, 255, 255));
        showpassword.setText("Show Password");
        showpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showpasswordActionPerformed(evt);
            }
        });
        jPanel1.add(showpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, -1, 20));

        jScrollPane2.setViewportView(Name);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 180, 30));

        Password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordActionPerformed(evt);
            }
        });
        jPanel1.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 180, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/airlinerproject/loginpagepicture.jpeg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 290));

        Password1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Password1ActionPerformed(evt);
            }
        });
        jPanel1.add(Password1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 240, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 300, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Admin Login page");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/airlinerproject/loginpagepicture.jpeg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 480, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void adminloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminloginActionPerformed
    

    String username = Name.getText();
    String password = new String(Password.getPassword());

    // Check if username or password are empty
    if (username.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter both username and password!", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Stop execution if either is empty
    }

    // Hardcoded admin credentials for validation
    String validUsername = "admin";
    String validPassword = "12345";

    // Check if the entered credentials match the valid ones
    if (username.equals(validUsername) && password.equals(validPassword)) {
        // Show success message and move to the next screen
        JOptionPane.showMessageDialog(this, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
        this.setVisible(false); // Close the login window
        Main main = new Main(); // Create and show the Main screen
        main.setVisible(true);
    } else {
        // If credentials are invalid, show an error message
        JOptionPane.showMessageDialog(this, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_adminloginActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
    int x = JOptionPane.showConfirmDialog(null, 
                "Are you sure you want to logout?", 
                "Exit Confirmation", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE);
        
     
        if (x == JOptionPane.YES_OPTION) {
            System.out.println("Exiting the program...");
            System.exit(0); 
        } else {
            System.out.println("Cancel logout"
                    + ". Continue working.");
        }
    
      
    }//GEN-LAST:event_CancelActionPerformed

    private void showpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showpasswordActionPerformed
   if (showpassword.isSelected()) {
       
        Password.setEchoChar((char) 0);
    } else {
        
        Password.setEchoChar('*');
    }                                            
   
    }//GEN-LAST:event_showpasswordActionPerformed

    private void PasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordActionPerformed

    private void Password1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Password1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Password1ActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JTextPane Name;
    private javax.swing.JPasswordField Password;
    private javax.swing.JPasswordField Password1;
    private javax.swing.JButton adminlogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JCheckBox showpassword;
    // End of variables declaration//GEN-END:variables
}
