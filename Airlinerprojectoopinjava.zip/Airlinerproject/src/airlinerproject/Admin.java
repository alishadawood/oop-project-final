package airlinerproject;

import java.io.FileWriter;
import java.io.IOException;

public class Admin extends Person {
    private String username;
    private String password;

    public Admin(String id, String firstName, String lastName, String username, String password) {
        super(id, firstName, lastName); 
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toFileFormat() {
        return "Admin ID: " + id +
               ", First Name: " + firstName +
               ", Last Name: " + lastName +
               ", Username: " + username +
               ", Password: " + password;
    }
    
    public boolean addAdmin() {
        try (FileWriter writer = new FileWriter("C:\\Users\\dell\\Desktop\\Flight\\Admin.txt", true)) {
            writer.write(this.toFileFormat() + System.lineSeparator());
            System.out.println("Admin saved successfully: " + this.toFileFormat());
            return true;
        } catch (IOException e) {
            System.err.println("Error saving admin: " + e.getMessage());
            return false;
        }
    }
}
