package airlinerproject;

import java.io.*;
import java.util.*;

public class Flight {
    private String flightNo;
    private String customerId;
    private String firstName;
    private String lastName;
    private String departure;
    private String duration;

    public Flight() {
    }
    private String dateOfFlight;
    private String seats;
    private String fare;

    private static final String FILE_PATH = "C:\\Users\\dell\\Desktop\\Flight\\Flights.txt";

    public Flight(String flightNo, String customerId, String firstName, String lastName, String departure, 
                  String duration, String dateOfFlight, String seats, String fare) {
        this.flightNo = flightNo;
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.departure = departure;
        this.duration = duration;
        this.dateOfFlight = dateOfFlight;
        this.seats = seats;
        this.fare = fare;
    }

    // Format flight data for writing to file
    public String toFileFormat() {
        return "Flight No: " + flightNo +
               ", Customer ID: " + customerId +
               ", First Name: " + firstName +
               ", Last Name: " + lastName +
               ", Departure: " + departure +
               ", Duration: " + duration +
               ", Date of Flight: " + dateOfFlight +
               ", Seats: " + seats +
               ", Fare: " + fare;
    }

    // Book a flight (add to file)
    public boolean bookFlight() {
        try (FileWriter writer = new FileWriter(FILE_PATH, true)) {
            writer.write(this.toFileFormat() + System.lineSeparator());
            System.out.println("Flight booked successfully: " + this.toFileFormat());
            return true;
        } catch (IOException e) {
            System.err.println("Error booking flight: " + e.getMessage());
            return false;
        }
    }

    // Delete a flight by flight number
    public static boolean deleteFlight(String flightNo) {
        File file = new File(FILE_PATH);
        File tempFile = new File("temp.txt");
        boolean isDeleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             FileWriter writer = new FileWriter(tempFile)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains("Flight No: " + flightNo)) {
                    writer.write(line + System.lineSeparator());
                } else {
                    isDeleted = true;
                }
            }

            file.delete();
            tempFile.renameTo(file);

        } catch (IOException e) {
            System.err.println("Error deleting flight: " + e.getMessage());
        }

        return isDeleted;
    }

    // Search for a flight by flight number
    public static Flight searchFlight(String flightNo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Flight No: " + flightNo)) {
                    String[] details = line.split(", ");
                    Map<String, String> flightDetails = new HashMap<>();
                    for (String detail : details) {
                        String[] keyValue = detail.split(": ");
                        flightDetails.put(keyValue[0].trim(), keyValue[1].trim());
                    }
                    return new Flight(
                        flightDetails.get("Flight No"),
                        flightDetails.get("Customer ID"),
                        flightDetails.get("First Name"),
                        flightDetails.get("Last Name"),
                        flightDetails.get("Departure"),
                        flightDetails.get("Duration"),
                        flightDetails.get("Date of Flight"),
                        flightDetails.get("Seats"),
                        flightDetails.get("Fare")
                    );
                }
            }
        } catch (IOException e) {
            System.err.println("Error searching for flight: " + e.getMessage());
        }
        return null;
    }

    // Update flight details
    public static boolean updateFlight(String flightNo, Flight updatedFlight) {
        File file = new File(FILE_PATH);
        File tempFile = new File("temp.txt");
        boolean isUpdated = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             FileWriter writer = new FileWriter(tempFile)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Flight No: " + flightNo)) {
                    writer.write(updatedFlight.toFileFormat() + System.lineSeparator());
                    isUpdated = true;
                } else {
                    writer.write(line + System.lineSeparator());
                }
            }

            file.delete();
            tempFile.renameTo(file);

        } catch (IOException e) {
            System.err.println("Error updating flight: " + e.getMessage());
        }

        return isUpdated;
    }

    // View all flights
    public static void viewAllFlights() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            System.out.println("All Flights:");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error viewing flights: " + e.getMessage());
        }
    }
}
